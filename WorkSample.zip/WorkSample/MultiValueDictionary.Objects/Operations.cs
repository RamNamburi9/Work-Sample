﻿using MultiValueDictionay.Entities;
using MultiValueDictionay.Interface;
using System;
using System.Collections.Generic;

namespace MultiValueDictionay.Objects
{
    public class Operations : IOperations
    {
        public string Add(UserInput input, Dictionary<string, List<String>> map)
        {
            var message = string.Empty;
            if (map.ContainsKey(input.Key))
            {
                var list = map[input.Key];
                if (list.Contains(input.Value))
                    message = MessageConstants.MemberExist;
                else
                {
                    list.Add(input.Value);
                    map[input.Key] = list;
                    message = MessageConstants.Add;
                }
            }
            else
            {
                map.Add(input.Key, new List<string> { input.Value });
                message = MessageConstants.Add;
            }

            return message;
        }

        public string Remove(UserInput input, Dictionary<string, List<String>> map)
        {
            var message = string.Empty;
            if (map.ContainsKey(input.Key))
            {
                var list = map[input.Key];
                if (!list.Contains(input.Value))
                {
                    message = MessageConstants.MemberNotExist;
                }
                else
                {
                    list.Remove(input.Value);

                    if (list.Count > 0)
                    {
                        map[input.Key] = list;
                        message = MessageConstants.Remove;
                    }
                    else
                        return RemoveAll(input, map);
                }
            }
            else
            {
                message = MessageConstants.MemberNotExist;
            }

            return message;
        }

        public string GetKeys(Dictionary<string, List<String>> map)
        {
            var message = string.Empty;
            if (map.Keys.Count > 0)
            {
                int i = 1;
                foreach (var key in map.Keys)
                {
                    if (i != map.Keys.Count)
                        message += (i + MessageConstants.MessagePrefix + key + Environment.NewLine);
                    else
                        message += (i + MessageConstants.MessagePrefix + key);
                    i++;
                }
            }
            else
            {
                message = MessageConstants.EmptySet;
            }

            return message;
        }

        public string GetMemebers(UserInput input, Dictionary<string, List<String>> map)
        {
            var message = string.Empty;

            if (map.ContainsKey(input.Key))
            {
                int i = 1;
                foreach (var member in map[input.Key])
                {
                    if (i != map[input.Key].Count)
                        message += (i + MessageConstants.MessagePrefix + member + Environment.NewLine);
                    else
                        message += (i + MessageConstants.MessagePrefix + member);
                    i++;

                }
            }
            else
            {
                message = MessageConstants.KeyNotExist;
            }

            return message;

        }

        public string KeyExists(UserInput input, Dictionary<string, List<String>> map)
        {
            return map.ContainsKey(input.Key).ToString();
        }


        public string RemoveAll(UserInput input, Dictionary<string, List<String>> map)
        {
            if (map.ContainsKey(input.Key))
            {
                map.Remove(input.Key);
                return MessageConstants.Remove;
            }
            else
            {
                return MessageConstants.KeyNotExist;
            }
        }

        public string MemberExists(UserInput input, Dictionary<string, List<String>> map)
        {
            if (map.ContainsKey(input.Key))
            {
                var list = map[input.Key];

                return list.Contains(input.Value).ToString();
            }
            else
            {
                return MessageConstants.MemberNotExist;
            }
        }

        public string GetItems(Dictionary<string, List<String>> map)
        {
            var message = string.Empty;

            if (map.Keys.Count > 0)
            {
                int i = 1;
                foreach (var key in map.Keys)
                {
                    foreach (var mem in map[key])
                    {
                        message += (i + MessageConstants.MessagePrefix + key + ": " + mem + Environment.NewLine);

                        i++;
                    }
                }
            }
            else
            {
                message = MessageConstants.EmptySet;
            }

            return message;
        }

        public string Clear(Dictionary<string, List<String>> map)
        {
            map.Clear();

            return MessageConstants.Clear;
        }

        public string GetAllMembers(Dictionary<string, List<String>> map)
        {
            var message = string.Empty;

            if (map.Keys.Count > 0)
            {
                var allmemebers = new List<string>();
                foreach (var key in map.Keys)
                {
                    allmemebers.AddRange(map[key]);
                }

                int i = 1;
                foreach (var mem in allmemebers)
                {
                    if (i != allmemebers.Count)
                        message += (i + MessageConstants.MessagePrefix + mem + Environment.NewLine);
                    else
                        message += (i + MessageConstants.MessagePrefix + mem);
                    i++;
                }
            }
            else
            {
                message = MessageConstants.EmptySet;
            }

            return message;
        }

    }
}

