﻿using MultiValueDictionay.Entities;
using MultiValueDictionay.Interface;
using System.Collections.Generic;

namespace MultiValueDictionay.Objects
{
   public class CommandFactory : ICommandFactory
    {
       public string ExecuteCommand(Dictionary<string, List<string>> map, UserInput userInput, IOperations operation)
        {
            string message = string.Empty;

            switch (userInput.Command)
            {
                case "ADD":
                    message = operation.Add(userInput, map);
                    break;
                case "REMOVE":
                    message = operation.Remove(userInput, map);
                    break;
                case "MEMBERS":
                    message = operation.GetMemebers(userInput, map);
                    break;
                case "REMOVEALL":
                    message = operation.RemoveAll(userInput, map);
                    break;
                case "KEYEXISTS":
                    message = operation.KeyExists(userInput, map);
                    break;
                case "MEMBEREXISTS":
                    message = operation.MemberExists(userInput, map);
                    break;
                case "ITEMS":
                    message = operation.GetItems(map);
                    break;
                case "CLEAR":
                    message = operation.Clear(map);
                    break;
                case "KEYS":
                    message = message = operation.GetKeys(map);
                    break;
                case "ALLMEMBERS":
                    message = operation.GetAllMembers(map);
                    break;
                default:
                    break;
            }

            return message;
        }
     
    }
}
