﻿using MultiValueDictionay.Interface;
using System.Collections.Generic;

namespace MultiValueDictionay.Objects
{
   public class Command : ICommand
    {
       public HashSet<string> GetCommands()
        {
            HashSet<string> commands = new HashSet<string>();

            commands.Add("ADD");
            commands.Add("REMOVE");
            commands.Add("KEYS");
            commands.Add("MEMBERS");
            commands.Add("REMOVEALL");
            commands.Add("KEYEXISTS");
            commands.Add("MEMBEREXISTS");
            commands.Add("ITEMS");
            commands.Add("CLEAR");
            commands.Add("ALLMEMBERS");
            return commands;
        }
    }
}
