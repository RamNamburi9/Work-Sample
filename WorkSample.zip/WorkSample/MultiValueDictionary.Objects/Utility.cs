﻿using MultiValueDictionay.Entities;
using MultiValueDictionay.Interface;
using System;
using System.Collections.Generic;

namespace MultiValueDictionay
{
   public class Utility : IUtility
    {

        public UserInput ParseUserInput(string commadtext)
        {
            string[] data = { "", "", "" };
            if (commadtext.Length > 0)
                data = commadtext.Split(' ');
            var userinput = new UserInput();

            userinput.Command = data.Length > 0 ? data[0] : string.Empty;
            userinput.Key = data.Length > 1 ? data[1] : string.Empty;
            userinput.Value = data.Length > 2 ? data[2] : string.Empty;

            return userinput;
        }

        public void Write(string message)
        {
            Console.Write(message);
        }

        public void WriteLine(List<string> messages)
        {
            foreach(var msg in messages)
                Console.WriteLine(msg);
        }

        public void WriteLine(string messages, bool isPrefix = true)
        {
             if(!string.IsNullOrEmpty(messages))

              if(isPrefix && messages.IndexOf(MessageConstants.MessagePrefix) == -1) 
                    Console.WriteLine(MessageConstants.MessagePrefix + messages);
                else 
                    Console.WriteLine(messages);
        }

        public string ReadLine()
        {
           return Console.ReadLine();
        }

        public void Validate(UserInput userInput, ICommand commands)
        {
            if (!commands.GetCommands().Contains(userInput.Command))
                WriteLine(MessageConstants.UnknownCommand + " " + userInput.Command, false);
        }

    }
}
