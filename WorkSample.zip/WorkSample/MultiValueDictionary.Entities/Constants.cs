﻿namespace MultiValueDictionay.Entities
{
    public static class MessageConstants
    {
        public const string CommandPrefix = "> ";
        public const string MessagePrefix = ") ";
        public const string MessageSuffix = "(";
        public const string UnknownCommand = "Unknown Command";
        public const string Add = "Added";
        public const string Remove = "Removed";
        public const string Clear = "Cleaerd";
        public const string EmptySet = "(empty set)";
        public const string MemberNotExist = "ERROR, member doesn't exist.";
        public const string MemberExist = "ERROR, member already exist.";
        public const string KeyNotExist = "ERROR, key does not exist.";
    }
}




