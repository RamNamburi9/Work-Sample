﻿namespace MultiValueDictionay.Entities
{
    public class  UserInput
    {
        public string Command { get; set; } = string.Empty;
        public string Key { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
    }
}


