﻿using MultiValueDictionay.Entities;
using System.Collections.Generic;

namespace MultiValueDictionay.Interface
{
   public interface IUtility
    {
        UserInput ParseUserInput(string commadtext);

        void Write(string message);

        void WriteLine(string msessage, bool isPrefix);

        void WriteLine(List<string> lstMsg);

        string ReadLine();

        public void Validate(UserInput userInput, ICommand commands);
       
    }
}
