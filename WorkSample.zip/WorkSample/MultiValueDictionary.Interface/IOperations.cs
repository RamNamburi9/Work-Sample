﻿using MultiValueDictionay.Entities;
using System;
using System.Collections.Generic;

namespace MultiValueDictionay.Interface
{
    public interface IOperations
    {
        string Add(UserInput input, Dictionary<string, List<String>> map);

        string Remove(UserInput input, Dictionary<string, List<String>> map);

        string RemoveAll(UserInput input, Dictionary<string, List<String>> map);

        string KeyExists(UserInput input, Dictionary<string, List<String>> map);

        string MemberExists(UserInput input, Dictionary<string, List<String>> map);

        string GetMemebers(UserInput input, Dictionary<string, List<String>> map);

        string GetKeys(Dictionary<string, List<String>> map);

        string GetItems(Dictionary<string, List<String>> map);

        string GetAllMembers(Dictionary<string, List<String>> map);

        string Clear(Dictionary<string, List<String>> map);

    }
}
