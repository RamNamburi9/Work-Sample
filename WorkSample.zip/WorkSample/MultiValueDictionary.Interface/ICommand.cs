﻿using System.Collections.Generic;

namespace MultiValueDictionay.Interface
{
   public  interface ICommand
    {
          HashSet<string> GetCommands();
    }
}
