﻿using Microsoft.Extensions.DependencyInjection;
using MultiValueDictionay.Entities;
using MultiValueDictionay.Interface;
using System;
using System.Collections.Generic;

namespace MultiValueDictionay
{
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary<string, List<String>> multiValueDictionay = 
                              new Dictionary<string, List<String>>();

            // Register Dependencies 
            var provider = ServiceExtensions.RegisterDI(args);

            // get objects 

            #region Get Objects

            var operation = provider.GetRequiredService<IOperations>();
            var utitliy = provider.GetRequiredService<IUtility>();
            var commands = provider.GetRequiredService<ICommand>();
            var commandFactory = provider.GetRequiredService<ICommandFactory>();

            #endregion

            while (true)
            {
                utitliy.Write(MessageConstants.CommandPrefix);

                var userInput = utitliy.ParseUserInput(utitliy.ReadLine());

                utitliy.Validate(userInput, commands);

                utitliy.WriteLine(commandFactory.ExecuteCommand(multiValueDictionay, userInput, operation), true);
            }
        }
    }

}

