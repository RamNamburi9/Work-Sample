﻿using System;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using MultiValueDictionay.Interface;
using MultiValueDictionay.Objects;

namespace MultiValueDictionay
{
    public static class ServiceExtensions
    {
        public static IServiceProvider RegisterDI(string[] args)
        {
            var host = CreateHostBuilder(args).Build();
            var serviceScope = host.Services.CreateScope();
            return serviceScope.ServiceProvider;
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureServices((_, services) =>
                    services
                     .AddTransient<IOperations, Operations>()
                     .AddTransient<IUtility, Utility>()
                     .AddTransient<ICommand, Command>()
                      .AddTransient<ICommandFactory, CommandFactory>()
                        );
        }
    }
}
